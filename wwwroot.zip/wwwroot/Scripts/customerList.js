// This is a simplified example for displaying a customer list.

// Sample customer data
const customers = [
    {
        firstName: "John",
        lastName: "Doe",
        email: "john@example.com",
        phone: "123-456-7890"
    },
    {
        firstName: "Jane",
        lastName: "Smith",
        email: "jane@example.com",
        phone: "987-654-3210"
    }
];

function displayCustomers() {
    const customerList = document.getElementById("customer-list");
    customerList.innerHTML = "";

    customers.forEach(customer => {
        const customerDiv = document.createElement("div");
        customerDiv.innerHTML = `
            <h3>${customer.firstName} ${customer.lastName}</h3>
            <p>Email: ${customer.email}</p>
            <p>Phone: ${customer.phone}</p>
        `;
        customerList.appendChild(customerDiv);
    });
}

// Display the customer list when the page loads
displayCustomers();
