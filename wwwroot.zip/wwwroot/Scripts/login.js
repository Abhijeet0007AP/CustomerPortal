// Sample login.js code
document.getElementById("login-button").addEventListener("click", function () {
    // Code for authenticating the user and handling the Bearer token
    // You should call the authentication API here and store the token for future requests
});
